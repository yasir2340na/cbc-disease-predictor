import React from 'react';
import { useLocation, useNavigate } from 'react-router-dom';

const transformInputs = (disease, inputs) => {
  const yesNoMap = val => (val === 'Yes' ? 1 : 0);
  const genderMap = val => (val === 'Male' ? 1 : 0);
  const bmiMap = { 'Underweight': 0, 'Normal': 1, 'Overweight': 2 };
  const socioMap = { 'Low': 0, 'Medium': 1, 'High': 2 };
  const urbanRuralMap = { 'Urban': 1, 'Rural': 0 };

  if (disease === 'anemia') {
    return [
      genderMap(inputs.gender),
      parseFloat(inputs.haemoglobin),
      parseFloat(inputs.mch),
      parseFloat(inputs.mchc),
      parseFloat(inputs.mcv)
    ];
  }

  if (disease === 'leukemia') {
    return [
      parseFloat(inputs.age),
      genderMap(inputs.gender),
      parseFloat(inputs.wbc),
      parseFloat(inputs.rbc),
      parseFloat(inputs.platelets),
      parseFloat(inputs.haemoglobin),
      yesNoMap(inputs.geneticMutation),
      yesNoMap(inputs.familyHistory),
      yesNoMap(inputs.smoking),
      yesNoMap(inputs.alcohol),
      yesNoMap(inputs.radiationExposure),
      yesNoMap(inputs.infection),
      bmiMap[inputs.bmi],
      yesNoMap(inputs.chronicIllness),
      yesNoMap(inputs.immuneDisease),
      socioMap[inputs.socioeconomic],
      urbanRuralMap[inputs.urbanRural]
    ];
  }

  return [];
};

const VerifyInputPage = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const { disease, formData } = location.state || {};

  if (!disease || !formData) {
    return <div className="p-10 text-center text-red-500">❌ No data provided</div>;
  }

  const finalValues = transformInputs(disease, formData);

  const handleConfirm = async () => {
    const response = await fetch('http://localhost:5000/predict', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ disease, inputs: formData })
    });

    const result = await response.json();
    navigate('/prediction-result', {
      state: { disease, results: { [disease]: result.prediction } }
    });
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-yellow-50">
      <div className="bg-white shadow-lg p-10 rounded-xl w-full max-w-3xl">
        <h2 className="text-2xl font-bold text-center mb-6 text-yellow-600">🔍 Verify Model Inputs</h2>
        <pre className="bg-gray-100 p-4 rounded-md text-sm overflow-x-auto">
{JSON.stringify(finalValues, null, 2)}
        </pre>
        <button
          onClick={handleConfirm}
          className="mt-6 w-full bg-green-600 text-white py-3 rounded-md hover:bg-green-700 transition"
        >
          ✅ Confirm & Predict
        </button>
      </div>
    </div>
  );
};

export default VerifyInputPage;
