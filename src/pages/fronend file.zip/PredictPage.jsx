// src/pages/PredictPage.jsx
import React from 'react';
import { Formik, Field, Form, ErrorMessage } from 'formik';
import * as Yup from 'yup';
import { useNavigate } from 'react-router-dom';

// Yup validation schema
const validationSchema = Yup.object({
  name: Yup.string().required("Patient's name is required"),
  age: Yup.number()
    .required('Age is required')
    .min(15, 'Age must be 15 or older')
    .typeError('Age must be a valid number'),
  gender: Yup.string().oneOf(['Male', 'Female'], 'Gender must be Male or Female').required('Gender is required'),
});

const PredictPage = () => {
  const navigate = useNavigate();

  const handleSubmit = (values) => {
    console.log(values); // You can still log patient data if needed
    navigate('/enter-cbc-values'); // Now move to CBC manual input page
  };
  

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-green-100 to-yellow-200">
      <div className="bg-white p-10 rounded-2xl shadow-2xl max-w-md w-full">
        <h1 className="text-3xl font-bold mb-6 text-blue-600">Patient Information</h1>

        <Formik
          initialValues={{ name: '', age: '', gender: '' }}
          validationSchema={validationSchema}
          onSubmit={handleSubmit}
        >
          <Form>
            {/* Patient Name */}
            <div className="mb-4">
              <label htmlFor="name" className="block text-lg font-semibold text-gray-700">Patient's Name</label>
              <Field
                id="name"
                name="name"
                className="w-full p-2 border border-gray-300 rounded-md mt-2"
              />
              <ErrorMessage name="name" component="div" className="text-red-600 text-sm" />
            </div>

            {/* Age */}
            <div className="mb-4">
              <label htmlFor="age" className="block text-lg font-semibold text-gray-700">Age</label>
              <Field
                id="age"
                name="age"
                type="number"
                className="w-full p-2 border border-gray-300 rounded-md mt-2"
              />
              <ErrorMessage name="age" component="div" className="text-red-600 text-sm" />
            </div>

            {/* Gender */}
            <div className="mb-6">
              <label className="block text-lg font-semibold text-gray-700">Gender</label>
              <div className="flex items-center space-x-4 mt-2">
                <label>
                  <Field type="radio" name="gender" value="Male" />
                  <span className="ml-2">Male</span>
                </label>
                <label>
                  <Field type="radio" name="gender" value="Female" />
                  <span className="ml-2">Female</span>
                </label>
              </div>
              <ErrorMessage name="gender" component="div" className="text-red-600 text-sm" />
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              className="w-full bg-blue-600 text-white py-3 rounded-md text-lg hover:bg-blue-700 transition duration-300"
            >
              Submit & Predict
            </button>
          </Form>
        </Formik>
      </div>
    </div>
  );
};

export default PredictPage;
