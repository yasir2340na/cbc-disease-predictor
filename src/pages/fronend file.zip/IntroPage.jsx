import React from 'react';
import { useNavigate } from 'react-router-dom';

const IntroPage = () => {
  const navigate = useNavigate();

  return (
    <div className="h-screen flex items-center justify-center bg-gradient-to-br from-blue-100 to-purple-200">
      <div className="text-center bg-white p-10 rounded-2xl shadow-2xl max-w-md">
        <h1 className="text-4xl font-bold mb-4 text-purple-700">CBC Disease Predictor</h1>
        <p className="text-gray-600 mb-6">
          Upload your CBC report and get instant predictions using AI.
        </p>
        <button
          onClick={() => navigate('/predict')}
          className="bg-purple-600 text-white px-6 py-3 rounded-full text-lg hover:bg-purple-700 transition duration-300"
        >
          Predict Now →
        </button>
      </div>
    </div>
  );
};

export default IntroPage;